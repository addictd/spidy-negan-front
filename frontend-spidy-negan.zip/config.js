module.exports = { //development
    PORT : 5050,
    SERVER_URL : "http://localhost",
    SERVER_PORT : 5060,
    TOKEN : 'xxx-dev-crawler'
}

// module.exports = { //production
//     PORT : 5050,
//     SERVER_URL : "http://localhost",
//     SERVER_PORT : 5060,
//     TOKEN : 'xxx-prod-crawler'
// }