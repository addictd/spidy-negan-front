open localhost:5050 in browser

Start by : 'npm run start'
