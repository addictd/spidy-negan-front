import React from 'react';
import './loader.scss';


const Loader = ({ }) => {
    return <div className="loader-wrapper">
        <div className="three_dot_loader"></div>
    </div>
}

export default Loader;